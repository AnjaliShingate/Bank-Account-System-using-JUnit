package com.bank;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class BankAccountTest {

    private BankAccount account;

    @BeforeEach
    void setUp() {
        account = new BankAccount();
    }

    @Test
    void testInitialBalanceIsZero() {
        assertEquals(0.0, account.getBalance());
    }

    @Test
    void testDepositIncreasesBalance() {
        account.deposit(1000.0);
        assertEquals(1000.0, account.getBalance());
    }

    @Test
    void testWithdrawDecreasesBalance() {
        account.deposit(1000.0);
        account.withdraw(400.0);
        assertEquals(600.0, account.getBalance());
    }

    @Test
    void testWithdrawMoreThanBalanceThrowsException() {
        account.deposit(300.0);
        Exception exception = assertThrows(IllegalArgumentException.class, () -> account.withdraw(500.0));
        assertEquals("Insufficient funds.", exception.getMessage());
    }

    @Test
    void testDepositNegativeAmountThrowsException() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> account.deposit(-100.0));
        assertEquals("Amount must be positive.", exception.getMessage());
    }

    @Test
    void testTransactionHistoryTracksActions() {
        account.deposit(500.0);
        account.withdraw(200.0);
        List<String> history = account.getTransactionHistory();
        assertEquals(2, history.size());
        assertEquals("Deposited: 500.0", history.get(0));
        assertEquals("Withdrew: 200.0", history.get(1));
    }
}
